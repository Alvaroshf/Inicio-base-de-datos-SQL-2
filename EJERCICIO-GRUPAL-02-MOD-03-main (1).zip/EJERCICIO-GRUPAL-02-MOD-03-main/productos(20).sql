Productos:

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES 
('P-001', 'Auriculares Inalámbricos Sony WH-1000XM4', 'Auriculares', 'Sony', 50),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES 
('P-002', 'Auriculares Inalámbricos Bose QuietComfort 35 II', 'Auriculares', 'Bose', 25),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES 
('P-003', 'Auriculares Inalámbricos Jabra Elite 85h', 'Auriculares', 'Jabra', 30),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES 
('P-004', 'Auriculares Inalámbricos Sennheiser Momentum 3', 'Auriculares', 'Sennheiser', 20),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES 
('P-005', 'Auriculares Inalámbricos Apple AirPods Pro', 'Auriculares', 'Apple', 40),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES 
('P-006', 'Auriculares Inalámbricos Samsung Galaxy Buds Pro', 'Auriculares', 'Samsung', 35),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES 
('P-007', 'Auriculares con Cable Audio-Technica ATH-M50x', 'Auriculares', 'Audio-Technica', 15),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES 
('P-008', 'Auriculares con Cable Beyerdynamic DT 990 Pro', 'Auriculares', 'Beyerdynamic', 10),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES 
('P-009', 'Auriculares con Cable AKG K371', 'Auriculares', 'AKG', 20),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES 
('P-010', 'Auriculares con Cable Shure SRH840', 'Auriculares', 'Shure', 18)

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES 
('P-011', 'Auriculares Inalámbricos JBL Quantum 800', 'Auriculares', 'JBL', 30),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES 
('P-012', 'Auriculares Inalámbricos Anker Soundcore Life Q35', 'Auriculares', 'Anker', 25),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES 
('P-013', 'Auriculares Inalámbricos Huawei FreeBuds 4i', 'Auriculares', 'Huawei', 40),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES 
('P-014', 'Auriculares Inalámbricos Razer Hammerhead True Wireless Pro', 'Auriculares', 'Razer', 20),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES
('P-015', 'Auriculares Inalámbricos JLab JBuds Air Sport', 'Auriculares', 'JLab', 15),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES
('P-016', 'Auriculares con Cable Grado Labs SR80e', 'Auriculares', 'Grado Labs', 10),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES
('P-017', 'Auriculares con Cable Philips SHP9500', 'Auriculares', 'Philips', 20),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES
('P-018', 'Auriculares con Cable Beyerdynamic DT 770 Pro', 'Auriculares', 'Beyerdynamic', 30),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES
('P-019', 'Auriculares con Cable Audio-Technica ATH-AD700X', 'Auriculares', 'Audio-Technica', 12),

INSERT INTO Producto (SKU, nombre, categoria, productor, cantidad_en_stock) VALUES
('P-020', 'Auriculares con Cable Sennheiser HD 600', 'Auriculares', 'Sennheiser', 18)
