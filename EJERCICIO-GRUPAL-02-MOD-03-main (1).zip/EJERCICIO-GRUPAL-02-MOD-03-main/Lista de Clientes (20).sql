LISTA DE CLIENTES:



INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000061', 'Juan Hernan', 'González Diaz', '915865678', 'Calle Mayor 1', 'Valparaiso', 'juang@gmail.com', '2022-01-01' now(), 300.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000062', 'María Ignacia', 'Rodríguez Fuentes', '912383649', 'Calle Ancha 2', 'Viña del Mar', 'mariar@gmail.com', '2022-01-02'now(), 120.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000063', 'Luis Enrique', 'Martínez Martínez', '91890680', 'Chipre 342', 'Ovalle', 'luismenrique2@gmail.com', '2022-01-03'now(), 210.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000064', 'Ana Maria', 'García Lopez', '94856481', 'Calle Larga 42', 'Calama', 'anaglopez234@gmail.com', '2022-03-04'now(), 70.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000065', 'Pablo Andres', 'Hernández Davinchi', '99643675', Bernado Ohiggins 5', 'Puchuncavi', 'pabloh@gmail.com', '2022-02-05'now(), 90.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000066', 'Lucía Teresa', 'Sánchez Franchesco', '982486354', 'San Espedita 69', 'Los Andes', 'lucias@gmail.com', '2022-01-06'now(), 100.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000067', 'David Dario', 'Gómez blanca', '913578535', 'Alberto Hurtado 1234', 'General Lagos', 'davidg24@gmail.com', '2022-02-07'now(), 22.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000068', 'Elena del Carmen', 'Pérez Diaz', '924634683', 'Timoteo sid 1348', 'Putre', 'elenadelcarmenp@gmail.com', '2022-04-08'now(), 79.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('0000669', 'Javier Felipe', 'Ruiz Flores', '986346426', 'Mozart Réquiem 1529', 'Iquique', 'javierrmozart@gmail.com', '2022-02-09'now(), 156.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000070', 'Carlos Andres', 'Santos Flores', '911492000', 'Calle Principal 11', 'Santiago', 'carloss@gmail.com', '2022-01-11'now(), 250.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000071', 'Natalia Yamilett', 'Vega Flores', '945001263', 'Octavio Orellano', 'Santiago', 'nataliav@gmail.com', '2022-01-12'now(), 210.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000072', 'Pedro Constantino', 'Díaz Anches', '978411021', 'Violeta Parra 123', 'Calle Larga', 'pedrod@gmail.com', '2022-01-13'now(), 26.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000073', 'Sara belen', 'López Cruz', '990907411', 'Pablo Neruda 1245', 'Arica', 'saral@gmail.com', '2022-01-14'now(), 225.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000074', 'Jorge Arturo', 'Alonso Piedra', '967454120', 'Calle brazil 124', 'Arica', 'jorgea@gmail.com', '2022-01-15'now(), 150.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000075', 'Marta Julieta', 'Fernández Vicuña', '937854951', 'Maipu 12', 'Los Andes', 'martaf@gmail.com', '2022-01-16'now(), 300.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000076', 'Diego Antonio ', 'Moreno Rubio', '93798546', 'San Valentin 1245', 'Caldera', 'diegom@gmail.com', '2022-02-18'now(), 320.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000077', 'Laura Valentina', 'Navarro Gomez', '91654876', 'Calle Octava 128', 'Santiago', 'lauran@gmail.com', '2022-01-18'now(), 60.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000078', 'Mario Vicente', 'Garrido Herrera', '945456989', 'San Antonio 245', 'Caldera', 'mariog@gmail.com', '2022-01-19'now(), 35.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000079', 'Isabel Fernanda', 'Gómez Muñoz', '978551239', 'Calle Décima 21', '	Taltal', 'isabelg@gmail.com', '2022-01-20'now(), 230.000 );

INSERT INTO cliente ( codigo, nombres, apellidos, telefono, direccion, comuna, correo_electronico, fecha_registro, Total_Pagado)
VALUES ('000080', 'David Alonso', 'Ferrer Rocher', '939655741', 'Calle Once 22', 'Viña del Mar', 'davidf@gmail.com', '2022-01-21'now(), 190.000 );
